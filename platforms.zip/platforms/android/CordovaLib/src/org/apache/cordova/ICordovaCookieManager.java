       self.assertEqual(pprint.pformat({"xy\tab\n": (3,), 5: [[]], (): {}}),
            r"{5: [[]], 'xy\tab\n': (3,), (): {}}")

    def test_subclassing(self):
        o = {'names with spaces': 'should be presented using repr()',
             'others.should.not.be': 'like.this'}
        exp = """\
{'names with spaces': 'should be presented using repr()',
 others.should.not.be: like.this}"""
        self.assertEqual(DottedPrettyPrinter().pformat(o), exp)

    def test_set_reprs(self):
        self.assertEqual(pprint.pformat(set()), 'set([])')
        self.assertEqual(pprint.pformat(set(range(3))), 'set([0, 1, 2])')
        self.assertEqual(pprint.pformat(set(range(7)), width=20), '''\
set([0,
     1,
     2,
     3,
     4,
     5,
     6])''')
        self.assertEqual(pprint.pformat(set2(range(7)), width=20), '''\
set2([0,
      1,
      2,
      3,
      4,
      5,
      6])''')
        self.assertEqual(pprint.pformat(set3(range(7)), width=20),
                         'set3([0, 1, 2, 3, 4, 5, 6])')

        self.assertEqual(pprint.pformat(frozenset()), 'frozenset([])')
        self.assertEqual(pprint.pformat(frozenset(range(3))),
     