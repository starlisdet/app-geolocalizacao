 D2D1_RENDERING_CONTROLS;

typedef struct D2D1_EFFECT_INPUT_DESCRIPTION {
    ID2D1Effect *effect;
    UINT32 inputIndex;
    D2D1_RECT_F inputRectangle;
} D2D1_EFFECT_INPUT_DESCRIPTION;

typedef struct D2D1_PRINT_CONTROL_PROPERTIES {
    D2D1_PRINT_FONT_SUBSET_MODE fontSubset;
    FLOAT rasterDPI;
    D2D1_COLOR_SPACE colorSpace;
} D2D1_PRINT_CONTROL_PROPERTIES;

typedef struct D2D1_STROKE_STYLE_PROPERTIES1 {
    D2D1_CAP_STYLE startCap;
    D2D1_CAP_STYLE endCap;
    D2D1_CAP_STYLE dashCap;
    D2D1_LINE_JOIN lineJoin;
    FLOAT miterLimit;
    D2D1_DASH_STYLE dashStyle;
    FLOAT dashOffset;
    D2D1_STROKE_TRANSFORM_TYPE transformType;
} D2D1_STROKE_STYLE_PROPERTIES1;

typedef struct D2D1_DRAWING_STATE_DESCRIPTION1 {
    D2D1_ANTIALIAS_MODE antialiasMode;
    D2D1_TEXT_ANTIALIAS_MODE textAntialiasMode;
    D2D1_TAG tag1;
    D2D1_TAG tag2;
    D2D1_MATRIX_3X2_F transform;
    D2D1_PRIMITIVE_BLEND primitiveBlend;
    D2D1_UNIT_MODE unitMode;
} D2D1_DRAWING_STATE_DESCRIPTION1;

typedef struct D2D1_POINT_DESCRIPTION {
    D2D1_POINT_2F point;
    D2D1_POINT_2F unitTangentVector;
    UINT32 endSegment;
    UINT32 endFigure;
    FLOAT lengthToEndSegment;
} D2D1_POINT_DESCRIPTION;

#ifndef D2D_USE_C_DEFINITIONS

interface ID2D1Properties : public IUnknown
{
    STDMETHOD_(UINT32, GetPropertyCount)() CONST PURE;
    STDMETHOD(GetPropertyName)(UINT32 index, PWSTR name, UINT32 nameCount) CONST PURE;
    STDMETHOD_(UINT32, GetPropertyNameLength)(UINT32 index) CONST PURE;
    STDMETHOD_(D2D1_PROPERTY_TYPE, GetType)(UINT32 index) CONST PURE;
    STDMETHOD_(UINT32, GetPropertyIndex)(PCWSTR name) CONST PURE;
    STDMETHOD(SetValueByName)(PCWSTR name, D2D1_PROPERTY_TYPE type, CONST BYTE *data, UINT32 dataSize) PURE;
    STDMETHOD(SetValue)(UINT32 index, D2D1_PROPERTY_TYPE type, CONST BYTE *data, UINT32 dataSize) PURE;
    STDMETHOD(GetValueByName)(PCWSTR name, D2D1_PROPERTY_TYPE type, BYTE *data, UINT32 dataSize) CONST PURE;
    STDMETHOD(GetValue)(UINT32 index, D2D1_PROPERTY_TYPE type, BYTE *data, UINT32 dataSize) CONST PURE;
    STDMETHOD_(UINT32, GetValueSize)(UINT32 index) CONST PURE;
    STDMETHOD(GetSubProperties)(UINT32 index, ID2D1Properties **subProperties) CONST PURE;

    HRESULT SetValueByName(PCWSTR name, CONST BYTE *data, UINT32 dataSize) {
        return SetValueByName(name, D2D1_PROPERTY_TYPE_UNKNOWN, data, dataSize);
    }

    HRESULT SetValue(UINT32 index, CONST BYTE *data, UINT32 dataSize) {
        return SetValue(index, D2D1_PROPERTY_TYPE_UNKNOWN, data, dataSize);
    }

    HRESULT GetValueByName(PCWSTR name, BYTE *data, UINT32 dataSize) CONST {
        return GetValueByName(name, D2D1_PROPERTY_TYPE_UNKNOWN, data, dataSize);
    }

    HRESULT GetValue(UINT32 index, BYTE *data, UINT32 dataSize) C